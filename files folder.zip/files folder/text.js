function addSomething (num,str) {
	var add = num + str;

	alert (add);

	addSomething (455,"programs to write") 
}