<html>
<head>
	<title>snake game</title>
	<style>
	#canvas{
		background-color: black;
	}
</style>
</head>
<body>
	<canvas id="canvas" width="500" height="500"></canvas>
	<script src="snake.js"></script>
</body>
</html>
	